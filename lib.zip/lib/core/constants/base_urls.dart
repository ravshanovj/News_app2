class BaseUrls {
  static const String baseUrl = 'http://192.168.42.155:3000';
  
  //? base url project
}
