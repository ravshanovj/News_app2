import 'package:news_app/core/constants/base_urls.dart';

class EndPointsUrls {
  static const String getNew = "${BaseUrls.baseUrl}/get";
  static const String addNew = "${BaseUrls.baseUrl}/add";
}