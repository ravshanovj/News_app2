import 'package:dio/dio.dart';
import 'package:news_app/core/constants/end_points_urls.dart';
import 'package:news_app/data/model/model.dart';

class NewsService {
  Future<dynamic> getNewsService() async {
    try {
      Response res = await Dio().get(EndPointsUrls.getNew);
      if (res.statusCode == 200) {
        return (res.data as List).map((e) => NewsModel.fromJson(e)).toList();
      } else {
        return res.statusMessage;
      }
    } catch (e) {
      return e.toString();
    }
  }
    }

